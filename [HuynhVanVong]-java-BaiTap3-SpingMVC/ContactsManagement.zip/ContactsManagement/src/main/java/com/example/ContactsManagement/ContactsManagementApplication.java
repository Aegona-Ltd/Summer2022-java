package com.example.ContactsManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactsManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContactsManagementApplication.class, args);
	}

}
